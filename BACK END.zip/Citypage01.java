package org.cityguide;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
   
public class Citypage01 extends Activity implements  View.OnClickListener
{ 
	 ImageButton imgButton1,imgButton2,imgButton3,imgButton4;
	 TextView    txt6,txt1,txt2,txt3,txt4,txt5;
	 String      e1,e2,e3; 
	     
	@Override
	 protected void onCreate(Bundle savedInstanceState)
     {
       super.onCreate(savedInstanceState);
       requestWindowFeature(Window.FEATURE_NO_TITLE);
       setContentView(R.layout.activity_citypage01);
       
       txt6=(TextView)findViewById(R.id.textView6); 
       txt1=(TextView)findViewById(R.id.textView1);  
       txt2=(TextView)findViewById(R.id.textView2); 
       txt3=(TextView)findViewById(R.id.textView3); 
       txt4=(TextView)findViewById(R.id.textView4); 
       txt5=(TextView)findViewById(R.id.textView5); 
       Intent i1 = getIntent();
       e1=i1.getStringExtra("e1");
       
       txt6.setText(e1); 
       
      	   
       imgButton1 =(ImageButton)findViewById(R.id.imageButton1);
       imgButton2 =(ImageButton)findViewById(R.id.imageButton2);
       imgButton3 =(ImageButton)findViewById(R.id.imageButton3);
       imgButton4 =(ImageButton)findViewById(R.id.imageButton4);
       
       imgButton1.setOnClickListener(this);
       imgButton2.setOnClickListener(this);
       imgButton3.setOnClickListener(this);
       imgButton4.setOnClickListener(this);
   
     }//oncreate

		 
	@Override
	public void onClick(View v)
	{
		
		if(v==imgButton1)
		{   
			e2="LIST OF "+txt1.getText().toString();
			Intent i1 = new Intent(Citypage01.this,Citypage02.class);
			i1.putExtra("e1",e1);
			i1.putExtra("e2",e2);
	        startActivity(i1);
			Toast.makeText(Citypage01.this,"You have Selected  Area & Button : "+ e1+e2,Toast.LENGTH_SHORT).show();
		}
		else if(v==imgButton4)
		{
			e2="LIST OF "+txt5.getText().toString();
			Intent i1 = new Intent(Citypage01.this,Citypage04.class);
			i1.putExtra("e1",e1);
			i1.putExtra("e2",e2);
	        startActivity(i1);
			Toast.makeText(Citypage01.this,"You have Selected  Area & Button : "+ e1+e2,Toast.LENGTH_SHORT).show();
		}
		else if(v==imgButton2)
		{
			e2="LIST OF "+txt2.getText().toString();
			Intent i1 = new Intent(Citypage01.this,Citypage05.class);
			i1.putExtra("e1",e1);
			i1.putExtra("e2",e2);
	        startActivity(i1);
			Toast.makeText(Citypage01.this,"You have Selected  Area & Button : "+ e1+e2,Toast.LENGTH_SHORT).show();
		}
		else if(v==imgButton3)
		{
			e2="LIST OF "+txt4.getText().toString();
			Intent i1 = new Intent(Citypage01.this,Citypage06.class);
			i1.putExtra("e1",e1);
			i1.putExtra("e2",e2);
	        startActivity(i1);
			Toast.makeText(Citypage01.this,"You have Selected  Area & Button : "+ e1+e2,Toast.LENGTH_SHORT).show();
		}	
		
		
		
		//msg1 = parent.getItemAtPosition(position).toString();
	 	 	//Toast.makeText(Citypage0.this,"OnitemClickListener : " +"\nGridview : "+ msg,Toast.LENGTH_SHORT).show();
	 	 	//   Intent i1 = new Intent(Citypage0.this,Citypage01.class);	 	 	  
 		  
			
			
			
			
		   //if(e1.equals("SULUR TOWN"))
        //		   Toast.makeText(getApplicationContext(),"PSG",Toast.LENGTH_LONG).show();
         //  else
        //	       Toast.makeText(getApplicationContext(),"Not PSG",Toast.LENGTH_LONG).show();
		
		
	} 

}//


