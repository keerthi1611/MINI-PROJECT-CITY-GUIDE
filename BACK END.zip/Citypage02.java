package org.cityguide;

import java.util.ArrayList;
import java.util.List;
 

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Citypage02 extends Activity
{
	 Button b1;
	
	 SQLiteDatabase db;
	 Cursor         cr;
	 GridView       gv;
	 ArrayAdapter<String>   adapter;
	 List<String>   li;
	 String         msg,e1,e2;
	 TextView       txt1,txt2;
    @Override
	public void onCreate(Bundle savedInstanceState)
	{ 
	  super.onCreate(savedInstanceState);
	  setContentView(R.layout.activity_citypage02);
	  
	  gv=(GridView)findViewById(R.id.gridView1);	
	  txt1=(TextView)findViewById(R.id.textView1);  
      txt2=(TextView)findViewById(R.id.textView2); 
      b1= (Button)findViewById(R.id.button1);   
      
      li=new ArrayList<String>();
         
      adapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,li);

      Intent i1 = getIntent();
      e1=i1.getStringExtra("e1");
      e2=i1.getStringExtra("e2");
     
      txt1.setText(e1); 
      txt2.setText(e2); 
      
      try 
      {  
    	  db = openOrCreateDatabase("cbedatabase", Context.MODE_PRIVATE, null);
          cr = db.rawQuery("SELECT * FROM collegetable WHERE areaname = '" +e1+ "'" , null);
        
          if(cr!=null)
          {  
        	 
        	  if(cr.moveToFirst())
              {
        		  Toast.makeText(getApplicationContext(), " Data to show", Toast.LENGTH_LONG).show(); 
                  do
                  {
               
            	    String collegename = cr.getString(1);
                    String about       = cr.getString(2);
                    String mailid      = cr.getString(3);
                
                    li.add(collegename);
                    li.add(about);
                    li.add(mailid);
               
                    adapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,li);
                    gv.setAdapter(adapter);
         
                 }while (cr.moveToNext());
           }//if
           else
           {
                Toast.makeText(getApplicationContext(), "No Data to show", Toast.LENGTH_LONG).show();
           }//else
       }//if
       
        gv.setOnItemClickListener(new OnItemClickListener()
        {
        	@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) 
			{
    
        		msg = parent.getItemAtPosition(position).toString();
 	 	 	    Toast.makeText(Citypage02.this,"OnitemClickListener : " +"\nGridview : "+ msg,Toast.LENGTH_SHORT).show();
 	 	 	    Intent i1 = new Intent(Citypage02.this,Citypage03.class);	 	 	  
	 		    i1.putExtra("e1",msg);   
                startActivity(i1);
              
			}
        	 
        });
        cr.close();
        db.close();
     }//try
     catch (Exception e)
     {
       Toast.makeText(Citypage02.this, "error....", Toast.LENGTH_SHORT).show();
     }
	 
  
  /*    
      b1.setOnClickListener(new View.OnClickListener() 
      {
          @Override
          public void onClick(View v) 
          {
            
                   Toast.makeText(getApplicationContext(),
                      "CBE Informatica ... Redirecting...",Toast.LENGTH_SHORT).show();
                   Intent i1 = new Intent(Citypage02.this,Citypage03.class);
                   startActivity(i1);
                     
                     
           }
         
       }); 
       
     */ 
      
	 }//onCreate
}//class areashow 









/*
 

public class Citypage02 extends Activity implements OnClickListener
{
	 String      e1,e2;
	
    Button         b1,b2;
   
    
    SQLiteDatabase db;
 

    
	@Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_citypage02);
  */      
       