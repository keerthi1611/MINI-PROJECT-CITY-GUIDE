package org.cityguide;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Citypage03 extends Activity 
{
    WebView    webView;
    String     e1; 

    /** Called when the activity is first created. */
    @Override
 public void onCreate(Bundle savedInstanceState) 
 {
     super.onCreate(savedInstanceState);
     setContentView(R.layout.activity_citypage03);
     webView = (WebView) findViewById(R.id.yourwebview);
     // force web view to open inside application
     webView.setWebViewClient(new MyWebViewClient());
     openURL();
     
     
 
 }

   private void openURL() 
   {
	   Intent i1 = getIntent();
	     e1=i1.getStringExtra("e1");
	    webView.loadUrl(e1);
	   //webView.loadUrl("http://www.psgtech.edu");
    }

    private class MyWebViewClient extends WebViewClient 
    {
      @Override
      public boolean shouldOverrideUrlLoading(WebView view, String url) 
      {
         view.loadUrl(url);
         return true;
       }
     }

}

