package org.cityguide;


import java.util.ArrayList;
import java.util.List;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Spinner;
import android.widget.Toast;

public class Citypage0 extends Activity
{
	
	 SQLiteDatabase db;
	 Cursor         cr;
	 GridView       gv;
	 ArrayAdapter<String>   adapter;
	 List<String>   li;
	 String   msg;
	 
    @Override
	public void onCreate(Bundle savedInstanceState)
	{
	  super.onCreate(savedInstanceState);
	  setContentView(R.layout.activity_citypage0);
	  
	  gv=(GridView)findViewById(R.id.gridView1);
	   
      li=new ArrayList<String>();
      
   
      adapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,li);
    
      try 
      {  
    	  db = openOrCreateDatabase("cbedatabase", Context.MODE_PRIVATE, null);
          cr = db.rawQuery("SELECT * FROM areatable",null);
         
          if(cr!=null)
          {  
            if(cr.moveToFirst())
            {
              do
             {
               
            	  String areaname=cr.getString(0);
                  String aboutarea=cr.getString(1);
               
               li.add(areaname);
               li.add(aboutarea);
               
               adapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,li);
               gv.setAdapter(adapter);
         
             }while (cr.moveToNext());
         }//if
         else
         {
            Toast.makeText(getApplicationContext(), "No Data to show", Toast.LENGTH_LONG).show();
          }//else
       }//if
       
        gv.setOnItemClickListener(new OnItemClickListener()
        {
        	@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) 
			{
        		
        		msg = parent.getItemAtPosition(position).toString();
 	 	 	    Toast.makeText(Citypage0.this,"OnitemClickListener : " +"\nGridview : "+ msg,Toast.LENGTH_SHORT).show();
 	 	 	    Intent i1 = new Intent(Citypage0.this,Citypage01.class);	 	 	  
	 		    i1.putExtra("e1",msg);   
                startActivity(i1);
              
			}
        	 
        });
        cr.close();
        db.close();
     }//try
     catch (Exception e)
     {
       Toast.makeText(Citypage0.this, "error....", Toast.LENGTH_SHORT).show();
     }
	   
    
      
      
	 }//onCreate
}//class areashow 

