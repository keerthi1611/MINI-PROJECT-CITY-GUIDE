package org.cityguide;


import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.database.Cursor;
 
import android.view.Menu;
import android.view.MenuItem;
 

public class Studentwelfaretable extends Activity implements OnClickListener
{
   	EditText       e1,e2,e4;
    Button         b1,b2;
    
    
    SQLiteDatabase db;
 
	/** Called when the activity is first created. */
    
	@Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studentwelfaretable);
        
        e1=(EditText)findViewById(R.id.editText1);
        e2=(EditText)findViewById(R.id.editText2);
        e4=(EditText)findViewById(R.id.editText4);
        
        b1=(Button)findViewById(R.id.button1);
        b1.setOnClickListener(this);
                
        b2=(Button)findViewById(R.id.button2);
        b2.setOnClickListener(this);
        
        db=openOrCreateDatabase("cbedatabase", Context.MODE_PRIVATE, null);
		db.execSQL("CREATE TABLE IF NOT EXISTS studentwelfaretable(areaname VARCHAR,studentwelfarename VARCHAR,about VARCHAR);");
    
    }//onCreate
 

	@Override
	public void onClick(View v) 
	{
		if(v==b1)
		{
			if(e1.getText().toString().trim().length()==0||e2.getText().toString().trim().length()==0||e4.getText().toString().trim().length()==0)
	       {
	    	   showMessage("Error .... ", "Please enter all field values");
	    	   return;
	       }//if
		   else
		   {
	         db.execSQL("INSERT INTO studentwelfaretable VALUES('"+e4.getText()+"','"+e1.getText()+"','"+e2.getText()+"');");
	         showMessage("Success", "one Record is added");
	         clearText();
		   }//else
		}//IF
		if(v==b2)
		{
			 Toast.makeText(getApplicationContext(),
                     "Redirecting to Next Activity...",Toast.LENGTH_SHORT).show();
             //db.close();
             redirect();     
		}
	}//onClick
	  
	public void redirect()
	{ 
	     Intent i1 = new Intent(Studentwelfaretable.this,Studenttableprocess.class);
         startActivity(i1);
         finish();
	}
 	 
 	 
	public void showMessage(String title,String message)
    {
    	Builder builder=new Builder(this);
    	builder.setCancelable(true);
    	builder.setTitle(title);
    	builder.setMessage(message);
    	builder.show();
	}
    public void clearText()
    {
    	e1.setText("");
    	e2.setText("");
    	
    	e4.setText("");
    	e1.requestFocus();
    }

}

