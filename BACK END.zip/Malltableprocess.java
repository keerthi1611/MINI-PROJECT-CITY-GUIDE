package org.cityguide;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import android.content.DialogInterface;

public class Malltableprocess extends Activity implements  View.OnClickListener
{
  	EditText       txt1,txt2,txt3,txt4;
 
    int            count;
    
    private Button btnprev;
    private Button btnnext;
    private Button btnupdate;
    private Button btndelete;
    
    SQLiteDatabase db;
    Cursor c;
 
    private static final String SELECT_SQL = "SELECT * FROM malltable";
 
    
    @Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_malltableprocess);
		
		openDatabase() ;
		
		txt1=(EditText)findViewById(R.id.areaname);
	    txt2=(EditText)findViewById(R.id.editText1);
	    txt3=(EditText)findViewById(R.id.editText3);
	    
	        
	    btnprev=(Button)findViewById(R.id.prev);
	    btnnext=(Button)findViewById(R.id.next);
	    btnupdate=(Button)findViewById(R.id.update);
	    btndelete=(Button)findViewById(R.id.delete);
	        
	    btnprev.setOnClickListener(this);
	    btnnext.setOnClickListener(this);
	    btnupdate.setOnClickListener(this);
	    btndelete.setOnClickListener(this); 
	    
	    c = db.rawQuery(SELECT_SQL, null);
        c.moveToFirst();
        showRecords();       
	         
	}

    protected void showRecords() 
    {
        String   areaname       = c.getString(0);
        String   mallname    = c.getString(1);
        String   about          = c.getString(2);
        
        
        txt1.setText(areaname);
        txt2.setText(mallname);
        txt3.setText(about);
        
       
    }
     
    public void showMessage(String title,String message)
    {
    	Builder builder=new Builder(this);
    	builder.setCancelable(true);
    	builder.setTitle(title);
    	builder.setMessage(message);
    	builder.show();
	}
	
	 public void clearText()
	    {
	    	txt1.setText("");
	    	txt2.setText("");	
	    	txt3.setText("");
	    		
	    	
	    	txt1.requestFocus();
	    }//clearText
	 
	 protected void openDatabase() 
	 {
	        db = openOrCreateDatabase("cbedatabase", Context.MODE_PRIVATE, null);
	  }//openDatabase
	 
	 protected void moveNext() {
	        if (!c.isLast())
	            c.moveToNext();
	        showRecords();
	    }//moveNext
	 
	    protected void movePrev() {
	        if (!c.isFirst())
	            c.moveToPrevious();
	         showRecords();
	 
	    }//movePrev 
	/*    
	    private void deleteRecord()
	    {
	        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
	        alertDialogBuilder.setMessage("Are you sure you want delete this record...?");
	 
	        alertDialogBuilder.setPositiveButton("Yes",new DialogInterface.OnClickListener()
	        {
	                    @Override
	            public void onClick(DialogInterface arg0, int arg1)
	            {
	              String na = txt1.getText().toString().trim();
	 
	               String sql = "DELETE FROM collegetable WHERE areaname='" + na + "';";
	              db.execSQL(sql);
	              Toast.makeText(getApplicationContext(), na+"  One Record is Deleted", Toast.LENGTH_LONG).show();
	              c = db.rawQuery(SELECT_SQL,null);
	              c.moveToFirst();
	              showRecords();       
	            }//onClick
	        });//setPositiveButton
	 
	        alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener()
	        {
	           @Override
	           public void onClick(DialogInterface arg0, int arg1)
	           {
	            }
	        });
	   
	        AlertDialog alertDialog = alertDialogBuilder.create();
	        alertDialog.show();
	 
	    }//deleteRecord
	  */  
	    protected void updateRecord()
	    {
	    	String name1       = c.getString(0);
	    	String areaname    = txt1.getText().toString().trim();
	    	String mallname = txt2.getText().toString().trim();
	    	String about       = txt3.getText().toString().trim();
	    	
	       
	 
	       String sql = "UPDATE malltable SET areaname='" + areaname + "', mallname='" + mallname + "', about='" + about + "' WHERE areaname='" + name1 + "';";
	      
	        if (areaname.equals("") || mallname.equals("")|| about.equals("")) 
	        {
	            Toast.makeText(getApplicationContext(), "You cannot save blank values", Toast.LENGTH_LONG).show();
	            return;
	        }//if
	 
	        db.execSQL(sql);
	        Toast.makeText(getApplicationContext(), "Records Saved Successfully", Toast.LENGTH_LONG).show();
	        c = db.rawQuery(SELECT_SQL, null);
	        c.moveToFirst();
	        showRecords();        
	        //c.moveToPosition(Integer.parseInt(name));
	   }
	    
	    @Override
	    public void onClick(View v) 
	    {
	        if (v == btnnext)
	        {
	            moveNext();
	        }
	  
	        if (v == btnprev)
	        {
	            movePrev();
	        }
	     /*   if (v == btndelete)
	        {
	            deleteRecord();
	            
	        }*/
	        if (v == btnupdate)
	        {
	            updateRecord();
	        }
	    }//onclick
}//onCreate
